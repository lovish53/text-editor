import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

function App() {
  const[value,setValue]=useState('')

  const modules={
    toolbar: [
      [{ header: [1, 2, 3, 4, 5, 6, false]}],
      [{font: []}],
      [{size: []}],
      ["bold",'italic','underline','strike','blockquote'],
      [
        {list: 'ordered'},
        {list: 'bullet'},
        {indent: '-1'},
        {indent: '+1'},
      ],
      ["link","image",'video']
    ]
  }

  function openFile(){

  }
  return ( 
    <div className="container-fluid">
      <div className="row">
        <div className="editor">
        <button id="add-file" onClick={()=>{openFile()}}>Open</button>
          <ReactQuill theme="snow" value={value} onChange={setValue}  className='editor'
            modules={modules}
          />
        </div>
      </div>
    </div>
   );
}

export default App;